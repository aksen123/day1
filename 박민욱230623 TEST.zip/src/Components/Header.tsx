import React from 'react'
import { styled } from 'styled-components'

const Title = styled.h1`
  color : blue;
  margin-bottom : 70px;

`

const Header = () => {
  return (
    <div>
      <Title>
        회원가입을 위해 <br/>
        정보를 입력해주세요
      </Title>
    </div>
  )
}

export default Header
