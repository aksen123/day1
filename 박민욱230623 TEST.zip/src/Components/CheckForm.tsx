import React from 'react'
import { styled } from 'styled-components'

const Container = styled.div`
  border-bottom : 1px solid #ddd;
  padding : 30px 0;
  margin-bottom : 30px
`
const RadioWrap = styled.div`
  font-size : 1.2rem;
  text-align : center;
`
const CheckWrap = styled.div`
  font-size : 0.8rem;
  text-align : center;
`
const CheckForm = () => {
  return (
    <Container>
      <RadioWrap>
        <input type="radio" name="gender" id="female" />
        <label htmlFor="female">여성</label>
        <input type="radio" name="gender" id="male" />
        <label htmlFor="male">남성</label>
      </RadioWrap>
      <CheckWrap>
        <input type="checkbox" name="" id="check" />
        <label htmlFor="check">이용약관 개인정보 수집 및 이동, 마케팅 활용 선택에 모두 동의합니다</label>
      </CheckWrap>
    </Container>
  )
}

export default CheckForm
