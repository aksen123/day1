import React from 'react'
import { styled } from 'styled-components'

const Container = styled.div`
margin-bottom : 30px;
`
const Inputwrap = styled.div`
  width: 100%;
  margin-bottom : 30px;
`
const Title = styled.div`
  color : grey;
  margin-bottom : 10px;
`
const Input = styled.input`
width: 100%;
  border: none;
  border-bottom : 1px solid #ddd;
  outline : none;
  font-size: 1.2rem
`

const Form = ({state, onChange, refs}) => {
  

  return (
    <Container>
      <Inputwrap>
        <Title>*이메일</Title>
        <Input ref={refs.email} name='email' value={state.email} type="text" onChange={onChange} />
      </Inputwrap>
      <Inputwrap>
        <Title>*이름</Title>
        <Input ref={refs.name} name='name' value={state.name} type="text" onChange={onChange} />
      </Inputwrap>
      <Inputwrap>
        <Title>*비밀번호</Title>
        <Input ref={refs.pw1} name='pw1' value={state.pw1} type="password" onChange={onChange}/>
      </Inputwrap>
      <Inputwrap>
        <Title>*비밀번호 확인</Title>
        <Input ref={refs.pw2} name= 'pw2' value={state.pw2} type="password" onChange={onChange}/>
      </Inputwrap>
    </Container>
  )
}

export default Form
