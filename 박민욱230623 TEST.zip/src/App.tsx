import React,{useState,useRef, useEffect} from 'react'
import { styled } from 'styled-components'
import Header from './Components/Header'
import Form from './Components/Form'
import CheckForm from './Components/CheckForm'


const Container = styled.div`
width: 500px;
text-align: left;
padding: 20px 70px;
box-shadow: 3px 3px 10px rgb(0, 0, 200);
`
const Button = styled.button`
  display: block;
  width: 100%;
  background-color : #fff;
  font-size: 1.2rem;
  padding: 20px;
  border : none; 
  border : 1px solid blue;
  border-radius : 5px;
  &:Hover {
    background-color : blue;
    color : #fff
  }
  
`
const App = () => {

  const refs = {
    email : useRef<any>(),
    name : useRef<any>(),
    pw1 : useRef<any>(),
    pw2 : useRef<any>()
  }
  const [state, setState] = useState({
    email : '',
    name: '',
    pw1 : '',
    pw2 : ''
  })
  const buttonEvent = () => {
    
    if(refs.email.current.value === '') {
      refs.email.current.focus();
      refs.email.current.value = "이메일을 입력해주세요"
    }
    if(refs.name.current.value === '') refs.name.current.focus()
    if(refs.pw1.current.value === '') refs.pw1.current.focus()
    if(refs.pw2.current.value === '') refs.pw2.current.focus()
    }
  const onChangeInput = (e) => {
    setState({
      ...state, [e.target.name]: e.target.value
    })
  }
  return (
    <Container>
      <Header />
      <Form state={state} onChange = {onChangeInput} refs ={refs}/>
      <CheckForm />
      <Button onClick={buttonEvent}>가입하기</Button>
    </Container>
  )
}

export default App
