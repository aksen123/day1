

const url = "https://jsonplaceholder.typicode.com/comments"

function load() {

fetch(url)
.then(response => response.json())
.then(data =>{
  document.querySelector("#log").innerHTML = data
})
}