
let clock = setInterval(() => {
  const time = new Date();
  const h = time.getHours();
  const m = time.getMinutes();
  const s = time.getSeconds()
  const hLine = document.querySelector(".lineHour");
  const mLine = document.querySelector(".lineMin");
  const sLine = document.querySelector(".lineSec");

  const degH = h * (360 / 12) + m * (360/ 12 / 60 );
  const degM = m * (360 / 60 );
  const degS = s * (360 / 60 );

  hLine.style.transform = `rotate(${degH}deg)`
  mLine.style.transform = `rotate(${degM}deg)`
  sLine.style.transform = `rotate(${degS}deg)`
}, 1000);
