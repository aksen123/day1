const text = document.querySelector('input[type=text]');

function add() {
  let list;
  if(localStorage.getItem("key") === null) {
    list = [];
  }else {
    list = JSON.parse(localStorage.getItem("key"))
  }

  text.value === "" ? false : list.push(text.value) 
  localStorage.setItem("key", JSON.stringify(list));
  text.value = ""
};

function deleteKey() {
  let list;
  if(localStorage.getItem("key") === null) {
    list = [];
  }else {
    list = JSON.parse(localStorage.getItem("key"))
  }

  let idx = list.indexOf(text.value);
  console.log(idx)
  list.splice(idx,1);

  localStorage.setItem("key", JSON.stringify(list))
}


function allDelete() {
  localStorage.removeItem("key");
}