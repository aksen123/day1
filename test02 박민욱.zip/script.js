
const text = document.querySelector('input[type=text]');

// function add() {
//   let list;
//   if(localStorage.getItem("item") === null) {
//     list = [];
//   }else {
//     list = JSON.parse(localStorage.getItem("item"))
//   }

//   text.value === "" ? false : list.push(text.value);
//   localStorage.setItem("item", JSON.stringify(list));
//   text.value = ""
// };


// function load() {
//   let list;
//   if(localStorage.getItem("item") === null) {
//     list = [];
//   }else {
//     list = JSON.parse(localStorage.getItem("item"));
//     console.log(list)
//   }
//   text.value = list;
// }

function add2() {
  text.value === "" ? false :
  localStorage.setItem("key", JSON.stringify(text.value));
  text.value = ""
}

function load2() {
  let str = JSON.parse(localStorage.getItem("key"));
  text.value = str
}