import { test } from "./test";

test("./tsconfig.json")
.then((content: string) => {
    console.log(content);
    return test(".")
  })
  .catch((err:Error) => console.log(`error: `, err.message))
