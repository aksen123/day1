
import { readFile } from "fs";
export const test = (filename: string): Promise<string> => {
  
  return  new Promise<string>((resolve: (value: string) => void, reject: (error: Error) => void) => {
    readFile(filename, (err: Error, buffer: Buffer) => {
      if(err) reject(new Error('error!!!!'))
      else resolve(buffer.toString());
    })
  })
}