export const intro = {
  title: "안녕하세요",
  message: "박민욱입니다.",
};
