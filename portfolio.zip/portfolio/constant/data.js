export const projects = [
  {
    title: "Portfolio Page",
    desc: ["설명12345679", "설명2", "설명3", "설명4"],
    images: [
      "./img/test/pic-1.jpg",
      "./img/test/pic-2.jpg",
      "./img/test/pic-3.jpg",
      "./img/test/pic-4.jpg",
    ],
  },

  {
    title: "Mobile WebPage",
    desc: ["설명2"],
    images: [
      "./img/test/bg-1.jpg",
      "./img/test/bg-2.jpg",
      "./img/test/bg-3.jpg",
      "./img/test/bg-4.jpg",
    ],
  },

  {
    title: "Responsive Page",
    desc: ["설명3"],
    images: [],
  },

  {
    title: "...",
    desc: ["설명4"],
    images: [],
  },

  {
    title: "...",
    desc: ["설명5"],
    images: [],
  },

  {
    title: "...",
    desc: ["설명6"],
    images: [],
  },
];
