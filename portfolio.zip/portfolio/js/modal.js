import { projects } from "../constant/data.js";
import { animatedText } from "./animation-text.js";

let viewBtns = document.querySelectorAll(".show");
const modal = document.querySelector(".modal_wrap");
const bigPic = document.querySelector(".slider");

viewBtns.forEach((e) => {
  e.addEventListener("click", function () {
    modal.style.display = "flex";
    modal.style.transform = "scale(1)";

    const project = projects[this.dataset.modal];
    document.querySelector(".modal_title h2").innerText = project.title;
    document.getElementById("desc").innerHTML = "";

    animatedText("#desc", project.desc);

    const imagesElement = document.querySelector(".smallPic");
    imagesElement.innerHTML = "";
    bigPic.src = project.images[0];

    project.images.map((image) => {
      // console.log(image);
      const element = document.createElement("img");
      element.src = image;
      element.width = 150;
      imagesElement.append(element);
      element.addEventListener("click", function () {
        bigPic.src = this.src;
      });
    });
  });
});

const modalClose = document.querySelector("#closeBtn");
modalClose.addEventListener("click", function close() {
  modal.style.transform = "scale(0)";
});
