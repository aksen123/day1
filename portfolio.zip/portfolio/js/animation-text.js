/**
 * 애니메이션 텍스트
 * @param {*} selector 셀렉터
 * @param {*} object 문자열 or 문자열 배열
 * @param {*} callback 콜백 (Optional)
 */
export function animatedText(selector, object, callback) {
  const element = document.querySelector(selector);
  element.innerHTML = "";

  // 글자 애니메이션 효과
  let intervalId = -1;
  let descIndex = 0;
  let charIndex = 0;
  let descElement = null;
  let chars = [];
  const delay = 100;

  setDisplayInterval();

  function setDisplayInterval() {
    chars = Array.isArray(object)
      ? object[descIndex].split("")
      : object.split("");
    intervalId = setInterval(callbackDisplayText, delay);
  }

  function callbackDisplayText() {
    if (charIndex === 0) descElement = document.createElement("p");
    descElement.innerHTML += chars[charIndex];
    element.appendChild(descElement);
    charIndex += 1;

    if (chars.length === charIndex) {
      clearInterval(intervalId);

      if (Array.isArray(object)) {
        descElement = null;
        charIndex = 0;
        descIndex += 1;
        setDisplayInterval();
      }

      if (callback) callback();
    }
  }
}
