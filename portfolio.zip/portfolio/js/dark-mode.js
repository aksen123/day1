// ########## Dark Btn ##########
const btns = document.querySelectorAll(".dark .bi");
const remotes = document.querySelectorAll(".control .bi");
const modal = document.querySelector(".modal_wrap");

const left = document.querySelector(".left_scetion");
const right = document.querySelector(".Right_page");

remotes.forEach((e) => {
  e.addEventListener("click", (e) => {
    [...btns].map((element) => element.classList.toggle("active"));
    [...remotes].map((element) => element.classList.toggle("active"));
    toggleDayAndNight(e.target.id === "day");
  });
});

function toggleDayAndNight(isDay) {
  const white = "#fff";
  const black = "#000";

  left.style.color = isDay ? white : black;
  left.style.backgroundColor = isDay ? black : white;
  right.style.color = isDay ? white : black;
  right.style.backgroundColor = isDay ? black : white;
  profileSection.style.color = isDay ? white : black;
  profileSection.style.backgroundColor = isDay ? "#222" : white;
  projectSection.style.color = isDay ? white : black;
  projectSection.style.backgroundColor = isDay ? "#222" : white;
  modal.style.color = isDay ? white : black;
  modal.style.backgroundColor = isDay ? "#222" : "#eee";
}
