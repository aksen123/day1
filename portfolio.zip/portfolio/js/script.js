import { intro } from "../constant/intro.js";
import { animatedText } from "./animation-text.js";

document.addEventListener("DOMContentLoaded", function () {
  animatedText(".intro #title", intro.title, () => {
    animatedText(".intro #message", intro.message, () => {});
  });
});

// ########## Section Btn ##########
/**
 * Section Btn
 */
const intBtn = document.querySelector("#intBtn");
const pjBtn = document.querySelector("#pjBtn");
// ## Section
const profileSection = document.querySelector(".profile .wrap");
const projectSection = document.querySelector(".project .wrap");

intBtn.addEventListener("click", () => {
  profileSection.classList.remove("on2");
  projectSection.classList.add("on2");
});

pjBtn.addEventListener("click", () => {
  projectSection.classList.remove("on2");
  profileSection.classList.add("on2");
});
