const originBtn = document.querySelector("#originBtn");
const selecBtn = document.querySelector("#selecBtn");
const result = document.querySelector("#result");
const test = document.querySelector("#test");

let luckNum = [...Array(45).keys()].map((value) => value + 1);

originBtn.addEventListener("click", () => {
  result.innerHTML = "";
  const removeBtns = document.querySelectorAll(":checked");
  const removeNums = [...removeBtns].map((element) => Number(element.value));

  luckNum = luckNum
    .map((value) => {
      if (!removeNums.includes(value)) return value;
    })
    .filter((value) => value !== undefined);

  let count = 0;

  const intervalId = setInterval(() => {
    let index = Math.floor(Math.random() * luckNum.length);
    const num = luckNum[index];
    luckNum[index] = undefined;
    luckNum = luckNum.filter((value) => value !== undefined);
    count += 1;

    let ball = document.createElement("span");
    ball.className = "ball";
    ball.innerHTML = num;
    ball.classList.toggle(
      num <= 10
        ? "color1"
        : num <= 20
        ? "color2"
        : num <= 30
        ? "color3"
        : num <= 40
        ? "color4"
        : "color5"
    );

    result.appendChild(ball);

    [...document.querySelectorAll(".ball")]
      .sort(
        (elementA, elementB) =>
          Number(elementA.innerHTML) - Number(elementB.innerHTML)
      )
      .map((element) => element)
      .forEach((item) => result.appendChild(item));

    if (count === 6) {
      clearInterval(intervalId);
    }
  }, 500);
});
