import { str1,str2 } from "./MyClass1.js";
import {  } from "./MyClass2.js";


document.querySelector("#log").innerHTML = `
  <p>${str1}</p>
  <p>${str2}</p>
` 